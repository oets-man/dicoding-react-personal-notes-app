import { Icon } from '@iconify/react/dist/iconify.js';
import PropTypes from 'prop-types';

function ButtonNormal({ children, iconName, disabled, ...props }) {
	return (
		<button
			{...props}
			disabled={disabled}
			className={`
                flex items-center px-4 py-2 m-2 text-sm rounded-md shadow-sm
                ${
					disabled
						? 'bg-slate-300 text-slate-500 cursor-not-allowed dark:bg-slate-700 dark:text-slate-400'
						: 'bg-slate-50 text-slate-900 ring-1 ring-inset ring-slate-600 hover:bg-slate-100 dark:bg-slate-800 dark:text-slate-200 dark:hover:bg-slate-700'
				}
            `}
		>
			{iconName && !disabled && <Icon className='inline mr-2' icon={iconName} width='1.5em' height='1.5em' />}
			{children}
		</button>
	);
}

function ButtonDanger({ children, iconName, disabled, ...props }) {
	return (
		<button
			{...props}
			disabled={disabled}
			className={`
                px-4 py-2 m-2 text-sm rounded-md shadow-sm
                ${
					disabled
						? 'bg-red-200 text-red-400 cursor-not-allowed dark:bg-red-700 dark:text-red-500'
						: 'text-red-700 bg-slate-50 ring-1 ring-inset ring-red-600 hover:bg-red-100 dark:bg-red-800 dark:text-red-100 hover:dark:bg-red-700 dark:ring-red-300'
				}
            `}
		>
			{iconName && !disabled && <Icon className='inline mr-2' icon={iconName} width='1.5em' height='1.5em' />}
			{children}
		</button>
	);
}

ButtonNormal.propTypes = {
	children: PropTypes.node.isRequired,
	iconName: PropTypes.string,
	disabled: PropTypes.bool,
};

ButtonDanger.propTypes = {
	children: PropTypes.node.isRequired,
	iconName: PropTypes.string,
	disabled: PropTypes.bool,
};

export { ButtonNormal, ButtonDanger };
